 <!-- Sección de Boletín Informativo Comienza -->
 <section class="newslatter-section">
            <div class="container">
                <div class="newslatter-inner set-bg" data-setbg="img/3.jpg">
                    <div class="ni-text">
                        <h3>Suscríbete al Boletín</h3>
                        <p>Suscríbete a nuestro boletín y mantente al día con las noticias legales</p>
                    </div>
                    <form action="#" class="ni-form">
                        <input type="text" placeholder="Tu correo electrónico">
                        <button type="submit">Suscribirse</button>
                    </form>
                </div>
            </div>
        </section>
    <!-- Sección de Boletín Informativo Termina -->